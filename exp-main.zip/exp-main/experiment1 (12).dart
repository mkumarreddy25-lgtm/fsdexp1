import 'dart:io';
void main(){
  var firstName = "John";
  var lastName = "Doe";
  int num1 = 10;
  int num2 = 3;
  int sum = num1 + num2;
  int diff = num1 - num2;
  int mul = num1 * num2;
  double div = num1 / num2;
  print("Enter number:");
  int? number = int.parse(stdin.readLineSync()!);
  print("The entered number is ${number}");
  print("The sum is $sum");
  print("The diff is $diff");
  print("The mul is $mul");
  print("The div is $div");
  print("Full name is $firstName $lastName");
}

OUTPUT:
Enter number:
10
The entered number is 10
The sum is 13
The diff is 7
The mul is 30
The div is 3.3333333333333335
Full name is John Doe

Process finished with exit code 0
  
